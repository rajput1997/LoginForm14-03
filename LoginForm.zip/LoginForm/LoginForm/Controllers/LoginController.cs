﻿using DocumentFormat.OpenXml.Office2010.Excel;
using LoginForm.Models;
using Microsoft.AspNetCore.Mvc;
using Nest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace LoginForm.Controllers
{
    public class LoginController : Controller
    {
        private readonly LoginDbContext _auc;
        static string key { get; set; } = "A!9HHhi%XjjYY4YP2@Nob009X";
        public LoginController(LoginDbContext auc)
        {
            _auc = auc;
        }
        
        [HttpGet]
        public IActionResult Index()
        {
            var logn = _auc.UserRegistration.ToList();
            return View(logn);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Details(int Id)
        {
            var logn = _auc. UserRegistration.Where(e => e.UserId == Id).FirstOrDefault();
            return View(logn);
        }
        
        [HttpGet]
        public IActionResult Edit(int Id)
        {
            var logn = _auc.UserRegistration.Where(e => e.UserId == Id).FirstOrDefault();
            return View(logn);
        }
        [HttpGet]
        public IActionResult Delete(int Id)
        {
            var logn = _auc.UserRegistration.Where(e => e.UserId == Id).FirstOrDefault();
            return View(logn);
        }

        [HttpPost]
        public IActionResult Create(Login lo)
        {
            _auc.UserRegistration.Add(lo);
            _auc.SaveChanges();
            return  RedirectToAction("Index");
        }
       [HttpPost]
        public IActionResult Edit(Login lo)
        {
            _auc.UserRegistration.Update(lo);
            _auc.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpPost]
        public IActionResult Delete(Login lo)
        {
            _auc.UserRegistration.Remove(lo);
            _auc.SaveChanges();
            return RedirectToAction("Index");
        }
        //Encrypted Password
        public static string MD5Hash(string text)
        {

            using (var md5 = new MD5CryptoServiceProvider())
            {
                using (var tdes = new TripleDESCryptoServiceProvider())
                {
                    tdes.Key = md5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
                    tdes.Mode = CipherMode.ECB;

                    using (var transform = tdes.CreateEncryptor())
                    {
                        byte[] textBytes = UTF8Encoding.UTF8.GetBytes(text);
                        return Convert.ToBase64String(textBytes);
                    }
                }
            }
        }
        //Decrypted Pawwsord
        public static string MD5HashDecrpyt(string text)
        {
            using (var md5 = new MD5CryptoServiceProvider())
            {
                using (var tdes = new TripleDESCryptoServiceProvider())
                {
                    tdes.Key = md5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
                    tdes.Mode = CipherMode.ECB;

                    using (var transform = tdes.CreateDecryptor())
                    {
                        byte[] cipherBytes = Convert.FromBase64String(text);
                        return UTF8Encoding.UTF8.GetString(cipherBytes);
                    }
                }
            }
        }
    }
}

    

